#!/bin/sh
# Сборка ransom.mtp. Нужны: JDK 8+, Android SDK (platforms/android-XX/android.jar и build-tools/XX/d8).
# Пример:  ANDROID_HOME=$HOME/Android/Sdk ./build.sh
set -e
cd "$(dirname "$0")"
ANDROID_JAR="${ANDROID_JAR:-$(ls "$ANDROID_HOME"/platforms/*/android.jar | tail -1)}"
D8="${D8:-$(ls "$ANDROID_HOME"/build-tools/*/d8 | tail -1)}"
rm -rf build out && mkdir -p build/api build/classes out

# заглушки API мода (в .mtp НЕ попадают, реальные классы есть в самом моде)
javac -nowarn --release 8 -cp "$ANDROID_JAR" -d build/api $(find stubs/cat -name '*.java')
javac -nowarn -encoding UTF-8 --release 8 -cp "$ANDROID_JAR:build/api" -d build/classes src/ransom/margyt/*.java

"$D8" --release --min-api 23 --lib "$ANDROID_JAR" --classpath build/api \
      --output out $(find build/classes -name '*.class')

cp manifest.json icon.png out/
(cd out && rm -f ../ransom.mtp && zip -q -X ../ransom.mtp manifest.json classes.dex icon.png)
echo "Готово: $(pwd)/ransom.mtp"
