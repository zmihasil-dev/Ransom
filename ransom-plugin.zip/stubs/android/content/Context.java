package android.content;
public abstract class Context { public android.content.res.Resources getResources(){return null;} public Context getApplicationContext(){return null;} public java.io.File getFilesDir(){return null;} public ContentResolver getContentResolver(){return null;} public int checkSelfPermission(String p){return 0;} }
