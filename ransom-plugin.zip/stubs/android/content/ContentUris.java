package android.content;
public class ContentUris { public static android.net.Uri withAppendedId(android.net.Uri u,long id){return u;} }
