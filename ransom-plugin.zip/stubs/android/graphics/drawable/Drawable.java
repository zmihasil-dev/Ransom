package android.graphics.drawable;
public abstract class Drawable { public android.graphics.Rect getBounds(){return null;} }
