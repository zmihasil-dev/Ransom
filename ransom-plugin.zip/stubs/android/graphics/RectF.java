package android.graphics;
public class RectF { public float left,top,right,bottom; public RectF(){} public void set(float l,float t,float r,float b){} public boolean contains(float x,float y){return false;}
 public float width(){return 0;} public float centerX(){return 0;} public float centerY(){return 0;} }
