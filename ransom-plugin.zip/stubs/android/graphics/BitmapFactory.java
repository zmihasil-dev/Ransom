package android.graphics;
public class BitmapFactory { public static class Options { public boolean inJustDecodeBounds; public int inSampleSize; public int outWidth,outHeight; }
 public static Bitmap decodeStream(java.io.InputStream i,Rect r,Options o){return null;} public static Bitmap decodeFile(String p){return null;} }
