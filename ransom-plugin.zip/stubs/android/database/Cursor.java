package android.database;
public interface Cursor { boolean moveToNext(); long getLong(int i); void close(); }
