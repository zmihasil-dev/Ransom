package android.app;
public class Dialog { public Dialog(android.content.Context c){} public void setContentView(android.view.View v){} public android.view.Window getWindow(){return null;} public void show(){} public void dismiss(){} }
