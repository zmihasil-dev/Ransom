package ransom.margyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;

import java.util.ArrayList;
import java.util.Random;

/**
 * Событие Ransom: кнопка с табличкой «стоп» запускает глитч-вирус. По экрану разбросаны монеты —
 * найди 5 штук и нажми PAY в окне вымогателя. Слой прозрачный, касания проходят в приложение,
 * кроме кнопки, монет и кнопки PAY.
 */
final class RansomView extends View {

    interface Logger {
        void log(String s);
    }

    private static final int IDLE = 0, INTRO = 1, DOWNLOAD = 2, ACTIVE = 3, PAID = 4;
    private static final int NEED = 5, TOTAL = 8, MAX_WINS = 16;
    private static final long INTRO_MS = 1400L, DOWNLOAD_MS = 2000L, TIMER_MS = 60000L, PAID_MS = 2600L;

    private static final class Win {
        float x, y, w, h;
        int kind, seed;
        long born;
    }

    private static final class Coin {
        float x, y, phase;
        boolean taken;
    }

    private static final class Fly {
        float sx, sy;
        long t0;
    }

    private static final class Shard {
        float x, y, vx, vy, w, h, rot, vr;
        int color;
        long born;
        int life;
    }

    private final Logger logger;
    private final float dp;
    private final int slop;
    private final RansomSfx sfx;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private final RectF rect2 = new RectF();
    private final Random rnd = new Random();
    private final ArrayList<Win> wins = new ArrayList<Win>();
    private final ArrayList<Coin> coins = new ArrayList<Coin>();
    private final ArrayList<Fly> flies = new ArrayList<Fly>();
    private final ArrayList<Shard> shards = new ArrayList<Shard>();

    private Activity activity;
    private boolean running, drawFailed;
    private int state = IDLE;
    private long stateStart, activeStart, lastGlitchSfx, lastExtraWin, shakeUntil;
    private int collected, paidTotal;
    private boolean overtime;
    private boolean pendingFirstWin;

    // окно вымогателя
    private float rx, ry, rw, rh;
    private final RectF payRect = new RectF();
    private final RectF counterRect = new RectF();

    // кнопка
    private float bx = -1f, by = -1f;
    private final float br;
    private boolean downOnBtn, dragging, consumed;
    private float downX, downY, offX, offY;

    private final Runnable stepper = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            step();
            postOnAnimation(this);
        }
    };

    RansomView(Context context, Logger logger) {
        super(context);
        this.logger = logger;
        this.dp = context.getResources().getDisplayMetrics().density;
        this.slop = ViewConfiguration.get(context).getScaledTouchSlop();
        this.br = 21f * dp;
        this.sfx = new RansomSfx();
        setWillNotDraw(false);
        line.setStyle(Paint.Style.STROKE);
        text.setFakeBoldText(true);
    }

    void setActivity(Activity a) {
        activity = a;
    }

    void clearActivity(Activity a) {
        if (activity == a) activity = null;
    }

    void destroy() {
        running = false;
        removeCallbacks(stepper);
        resetInstant();
        sfx.release();
    }

    private void resetInstant() {
        state = IDLE;
        wins.clear();
        coins.clear();
        flies.clear();
        shards.clear();
        collected = 0;
        overtime = false;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        if (bx < 0f) {
            bx = 8f * dp + br;
            by = h * 0.38f;
        }
        bx = clamp(bx, br, w - br);
        by = clamp(by, br, h - br);
        layoutRansom();
    }

    private void layoutRansom() {
        float W = getWidth(), H = getHeight();
        rw = Math.min(W - 28f * dp, 320f * dp);
        rh = rw * 0.66f;
        rx = (W - rw) / 2f;
        ry = H * 0.56f - rh / 2f;
        float th = 11f * dp;
        float B = rh - th;
        float bottom = ry + rh;
        float bh = B * 0.30f;
        counterRect.set(rx + 8f * dp, bottom - bh + 4f * dp, rx + rw * 0.36f, bottom - 5f * dp);
        payRect.set(rx + rw * 0.40f, bottom - bh + 4f * dp, rx + rw - 8f * dp, bottom - 5f * dp);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        removeCallbacks(stepper);
        postOnAnimation(stepper);
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        removeCallbacks(stepper);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------ логика

    private void setState(int s) {
        state = s;
        stateStart = SystemClock.uptimeMillis();
    }

    private void startEvent() {
        resetInstant();
        setState(INTRO);
        sfx.play(RansomSfx.INTRO);
    }

    private void abortEvent() {
        resetInstant();
    }

    private void beginActive(long now) {
        activeStart = now;
        collected = 0;
        overtime = false;
        wins.clear();
        coins.clear();
        flies.clear();
        float W = getWidth(), H = getHeight();
        for (int i = 0; i < 9; i++) {
            Win w = newWin(W, H, now + i * 140L);
            wins.add(w);
        }
        for (int i = 0; i < TOTAL; i++) addCoin(W, H);
        lastExtraWin = now;
        sfx.play(RansomSfx.GLITCH);
    }

    private Win newWin(float W, float H, long born) {
        Win w = new Win();
        w.w = (90f + rnd.nextFloat() * 110f) * dp;
        w.h = w.w * (0.5f + rnd.nextFloat() * 0.3f);
        w.x = rnd.nextFloat() * Math.max(1f, W - w.w);
        w.y = H * 0.09f + rnd.nextFloat() * Math.max(1f, H * 0.78f - w.h);
        w.kind = rnd.nextInt(4);
        w.seed = rnd.nextInt();
        w.born = born;
        return w;
    }

    private void addCoin(float W, float H) {
        float r = 14f * dp;
        for (int tries = 0; tries < 40; tries++) {
            float x = r + rnd.nextFloat() * (W - 2f * r);
            float y = H * 0.1f + rnd.nextFloat() * (H * 0.8f);
            boolean ok = true;
            if (x - bx < br + r * 2f && x - bx > -(br + r * 2f) && y - by < br + r * 2f && y - by > -(br + r * 2f)) ok = false;
            if (x > payRect.left - r && x < payRect.right + r && y > payRect.top - r && y < payRect.bottom + r) ok = false;
            for (int i = 0; ok && i < coins.size(); i++) {
                Coin c = coins.get(i);
                if (!c.taken && Math.abs(c.x - x) < r * 3f && Math.abs(c.y - y) < r * 3f) ok = false;
            }
            if (ok || tries == 39) {
                Coin c = new Coin();
                c.x = x;
                c.y = y;
                c.phase = rnd.nextFloat() * 6.28f;
                coins.add(c);
                return;
            }
        }
    }

    private int coinsLeft() {
        int n = 0;
        for (int i = 0; i < coins.size(); i++) if (!coins.get(i).taken) n++;
        return n;
    }

    private void step() {
        try {
            long now = SystemClock.uptimeMillis();
            long age = now - stateStart;
            if (state == INTRO && age > INTRO_MS) setState(DOWNLOAD);
            else if (state == DOWNLOAD && age > DOWNLOAD_MS) {
                setState(ACTIVE);
                beginActive(now);
            } else if (state == PAID && age > PAID_MS) {
                resetInstant();
            } else if (state == ACTIVE) {
                if (!overtime && now - activeStart > TIMER_MS) {
                    overtime = true;
                    sfx.play(RansomSfx.ERROR);
                }
                if (overtime && now - lastExtraWin > 1800 && wins.size() < MAX_WINS) {
                    lastExtraWin = now;
                    wins.add(newWin(getWidth(), getHeight(), now));
                    sfx.play(RansomSfx.POP);
                }
                // монет всегда должно хватать на выкуп
                while (coinsLeft() + collected + flies.size() < NEED) addCoin(getWidth(), getHeight());
                // от монет, что отлетели, уже нечего ждать
                for (int i = flies.size() - 1; i >= 0; i--) {
                    if (now - flies.get(i).t0 > 380) {
                        flies.remove(i);
                        collected++;
                    }
                }
            }
            if (state != IDLE) invalidate();
            else invalidate();
        } catch (Throwable t) {
            safeLog("ransom: step failed: " + t);
        }
    }

    private boolean canPay() {
        return state == ACTIVE && collected >= NEED;
    }

    private void pay() {
        long now = SystemClock.uptimeMillis();
        collected -= NEED;
        sfx.play(RansomSfx.PAID);
        paidTotal++;
        // всё рассыпается на осколки
        for (int i = 0; i < wins.size(); i++) shatter(wins.get(i).x, wins.get(i).y, wins.get(i).w, wins.get(i).h, now, 12);
        shatter(rx, ry, rw, rh, now, 40);
        wins.clear();
        coins.clear();
        flies.clear();
        setState(PAID);
        try {
            performHapticFeedback(0);
        } catch (Throwable ignored) {
        }
    }

    private void shatter(float x, float y, float w, float h, long now, int count) {
        int[] pal = {0xFFE8294C, 0xFF00E5FF, 0xFFFF00A0, 0xFF3020FF, 0xFFE00000, 0xFFFFFFFF, 0xFF101020};
        for (int i = 0; i < count; i++) {
            Shard s = new Shard();
            s.x = x + rnd.nextFloat() * w;
            s.y = y + rnd.nextFloat() * h;
            s.vx = (rnd.nextFloat() - 0.5f) * 10f * dp;
            s.vy = (rnd.nextFloat() - 0.7f) * 8f * dp;
            s.w = (4f + rnd.nextFloat() * 10f) * dp;
            s.h = (3f + rnd.nextFloat() * 6f) * dp;
            s.rot = rnd.nextFloat() * 360f;
            s.vr = (rnd.nextFloat() - 0.5f) * 20f;
            s.color = pal[rnd.nextInt(pal.length)];
            s.born = now;
            s.life = 900 + rnd.nextInt(900);
            shards.add(s);
        }
    }

    private void collectCoin(Coin c) {
        c.taken = true;
        Fly f = new Fly();
        f.sx = c.x;
        f.sy = c.y;
        f.t0 = SystemClock.uptimeMillis();
        flies.add(f);
        sfx.play(RansomSfx.COIN);
        try {
            performHapticFeedback(0);
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------ касания

    private boolean hitButton(float x, float y) {
        float rr = br + 10f * dp;
        float dx = x - bx, dy = y - by;
        return dx * dx + dy * dy <= rr * rr;
    }

    private Coin hitCoin(float x, float y) {
        Coin best = null;
        float bd = Float.MAX_VALUE;
        float rr = 14f * dp + 14f * dp;
        for (int i = 0; i < coins.size(); i++) {
            Coin c = coins.get(i);
            if (c.taken) continue;
            float dx = x - c.x, dy = y - c.y;
            float d = dx * dx + dy * dy;
            if (d <= rr * rr && d < bd) {
                bd = d;
                best = c;
            }
        }
        return best;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        try {
            int a = e.getActionMasked();
            float x = e.getX(), y = e.getY();
            if (a == MotionEvent.ACTION_DOWN) {
                consumed = false;
                downOnBtn = hitButton(x, y);
                if (downOnBtn) {
                    dragging = false;
                    downX = x;
                    downY = y;
                    offX = bx - x;
                    offY = by - y;
                    ViewParent p = getParent();
                    if (p != null) p.requestDisallowInterceptTouchEvent(true);
                    return true;
                }
                if (state == ACTIVE) {
                    Coin c = hitCoin(x, y);
                    if (c != null) {
                        collectCoin(c);
                        consumed = true;
                        return true;
                    }
                    if (payRect.contains(x, y)) {
                        if (canPay()) pay();
                        else sfx.play(RansomSfx.ERROR);
                        shakeUntil = SystemClock.uptimeMillis() + 250;
                        consumed = true;
                        return true;
                    }
                }
                return false;
            }
            if (consumed) return true;
            if (!downOnBtn) return false;
            if (a == MotionEvent.ACTION_MOVE) {
                if (!dragging) {
                    float dx = x - downX, dy = y - downY;
                    if (Math.sqrt(dx * dx + dy * dy) > slop * 1.5f) dragging = true;
                }
                if (dragging) {
                    bx = clamp(x + offX, br, getWidth() - br);
                    by = clamp(y + offY, br, getHeight() - br);
                }
                return true;
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                downOnBtn = false;
                boolean tap = a == MotionEvent.ACTION_UP && !dragging;
                dragging = false;
                if (tap) {
                    if (state == IDLE) startEvent();
                    else abortEvent();
                }
                return true;
            }
            return true;
        } catch (Throwable t) {
            safeLog("ransom: touch failed: " + t);
            return false;
        }
    }

    // ------------------------------------------------------------ рисование

    @Override
    protected void onDraw(Canvas c) {
        try {
            long now = SystemClock.uptimeMillis();
            switch (state) {
                case INTRO:
                    drawIntro(c, now);
                    break;
                case DOWNLOAD:
                    drawDownload(c, now);
                    break;
                case ACTIVE:
                    drawActive(c, now);
                    break;
                case PAID:
                    drawPaid(c, now);
                    break;
                default:
                    break;
            }
            drawButton(c, now);
        } catch (Throwable t) {
            if (!drawFailed) {
                drawFailed = true;
                safeLog("ransom: draw failed: " + t);
            }
        }
    }

    private static int alphaColor(int rgb, float a) {
        int al = (int) (255f * Math.max(0f, Math.min(1f, a)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    private void octagon(float cx, float cy, float r) {
        path.reset();
        for (int k = 0; k < 8; k++) {
            float a = (float) (Math.PI / 8.0 + k * Math.PI / 4.0);
            float px = cx + (float) Math.cos(a) * r, py = cy + (float) Math.sin(a) * r;
            if (k == 0) path.moveTo(px, py);
            else path.lineTo(px, py);
        }
        path.close();
    }

    /** Табличка «стоп» с ладонью (как на картинке). */
    private void drawStop(Canvas c, float cx, float cy, float r) {
        fill.setShader(null);
        octagon(cx, cy, r);
        fill.setColor(0xFFB00000);
        c.drawPath(path, fill);
        octagon(cx, cy, r * 0.90f);
        line.setStrokeWidth(Math.max(1f, r * 0.055f));
        line.setColor(0xFFFFFFFF);
        c.drawPath(path, line);
        fill.setColor(0xFFFFFFFF);
        float u = r / 100f;
        // ладонь
        rect.set(cx - 30f * u, cy - 10f * u, cx + 30f * u, cy + 50f * u);
        c.drawRoundRect(rect, 28f * u, 28f * u, fill);
        // пальцы
        float[] tops = {-34f, -48f, -60f, -44f};
        for (int i = 0; i < 4; i++) {
            float l = -30f + i * 15.5f;
            rect.set(cx + l * u, cy + tops[i] * u, cx + (l + 13.5f) * u, cy + 4f * u);
            c.drawRoundRect(rect, 6.7f * u, 6.7f * u, fill);
        }
        // большой палец
        c.save();
        c.translate(cx + 28f * u, cy + 18f * u);
        c.rotate(30f);
        rect.set(-7f * u, -40f * u, 7f * u, 8f * u);
        c.drawRoundRect(rect, 7f * u, 7f * u, fill);
        c.restore();
    }

    private void glitchBars(Canvas c, long now, float intensity, int color) {
        rnd.setSeed(now / 70L * 31L + 7L);
        int n = (int) (6 + intensity * 10);
        float W = getWidth(), H = getHeight();
        for (int i = 0; i < n; i++) {
            float y = rnd.nextFloat() * H;
            float h = (2f + rnd.nextFloat() * 14f) * dp * intensity;
            float x = rnd.nextFloat() * W * 0.6f;
            float w = (0.2f + rnd.nextFloat() * 0.8f) * W;
            fill.setColor(alphaColor(color, 0.25f + rnd.nextFloat() * 0.35f));
            c.drawRect(x, y, x + w, y + h, fill);
        }
    }

    private void drawIntro(Canvas c, long now) {
        float W = getWidth(), H = getHeight();
        float age = (now - stateStart) / (float) INTRO_MS;
        fill.setShader(null);
        fill.setColor(alphaColor(0x1A0000, Math.min(0.82f, age * 2.2f)));
        c.drawRect(0f, 0f, W, H, fill);
        glitchBars(c, now, 0.6f + age, 0xFF1020);
        float pulse = 1f + 0.08f * (float) Math.sin(age * 30f);
        float r = Math.min(W, H) * (0.10f + 0.12f * Math.min(1f, age * 2f)) * pulse;
        float jx = (rnd.nextFloat() - 0.5f) * 6f * dp * age;
        drawStop(c, W / 2f + jx, H * 0.45f, r);
    }

    private void drawDownload(Canvas c, long now) {
        float W = getWidth(), H = getHeight();
        float age = (now - stateStart) / (float) DOWNLOAD_MS;
        fill.setShader(null);
        fill.setColor(0xCC260000);
        c.drawRect(0f, 0f, W, H, fill);
        glitchBars(c, now, 0.9f, 0xFF2030);
        int dots = 1 + (int) ((now / 260L) % 3L);
        StringBuilder sb = new StringBuilder("DOWNLOADING");
        for (int i = 0; i < dots; i++) sb.append('.');
        text.setTextAlign(Paint.Align.CENTER);
        text.setTextSize(15f * dp);
        text.setColor(0xFFFF4A5A);
        c.drawText(sb.toString(), W / 2f, H * 0.46f, text);
        float bw = Math.min(W * 0.6f, 240f * dp);
        rect.set(W / 2f - bw / 2f, H * 0.48f, W / 2f + bw / 2f, H * 0.48f + 8f * dp);
        fill.setColor(0xFF000000);
        c.drawRect(rect, fill);
        // «рваная» загрузка: растёт скачками
        float p = (float) Math.floor(age * 14f) / 14f;
        rect.set(rect.left, rect.top, rect.left + bw * p, rect.bottom);
        fill.setColor(0xFFE01030);
        c.drawRect(rect, fill);
    }

    private void drawWinBody(Canvas c, Win w, float x, float y, float ww, float hh, long now) {
        float th = Math.min(10f * dp, hh * 0.25f);
        // заголовок
        fill.setColor(0xFFE6E6E6);
        rect.set(x, y, x + ww, y + th);
        c.drawRect(rect, fill);
        fill.setColor(0xFF9A9A9A);
        for (int i = 0; i < 3; i++) c.drawCircle(x + ww - (5f + i * 7f) * dp, y + th / 2f, 1.8f * dp, fill);
        float by0 = y + th;
        float bh = hh - th;
        rnd.setSeed((long) w.seed * 131L + now / 90L);
        if (w.kind == 0) {
            int[] pal = {0xFF00E5FF, 0xFFFF00A0, 0xFF3020FF, 0xFFFFE000, 0xFF101030, 0xFFFF2020, 0xFFFFFFFF, 0xFF20FF60};
            int cols = 8, rows = 5;
            float cw = ww / cols, ch = bh / rows;
            for (int r = 0; r < rows; r++) {
                for (int q = 0; q < cols; q++) {
                    fill.setColor(pal[rnd.nextInt(pal.length)]);
                    c.drawRect(x + q * cw, by0 + r * ch, x + (q + 1) * cw + 0.5f, by0 + (r + 1) * ch + 0.5f, fill);
                }
            }
        } else if (w.kind == 1) {
            fill.setColor(0xFFE00000);
            c.drawRect(x, by0, x + ww, by0 + bh, fill);
            fill.setColor(0x40FF6060);
            c.drawCircle(x + ww / 2f, by0 + bh / 2f, bh * 0.38f, fill);
        } else if (w.kind == 2) {
            fill.setColor(0xFF0A0614);
            c.drawRect(x, by0, x + ww, by0 + bh, fill);
            int[] pal = {0xFFD01040, 0xFF8020A0, 0xFFFF4060, 0xFF3A1060};
            for (int i = 0; i < 9; i++) {
                float sy = by0 + rnd.nextFloat() * bh;
                float sh = (1.5f + rnd.nextFloat() * 5f) * dp;
                float sx = x + rnd.nextFloat() * ww * 0.3f;
                float sw = ww * (0.4f + rnd.nextFloat() * 0.6f);
                fill.setColor(pal[rnd.nextInt(pal.length)]);
                c.drawRect(sx, sy, Math.min(x + ww, sx + sw), Math.min(by0 + bh, sy + sh), fill);
            }
        } else {
            fill.setColor(0xFFE0304F);
            c.drawRect(x, by0, x + ww, by0 + bh, fill);
        }
        line.setStrokeWidth(1f * dp);
        line.setColor(0xCCFFFFFF);
        rect.set(x, y, x + ww, y + hh);
        c.drawRect(rect, line);
    }

    private static float easeOutBack(float t) {
        float s = 1.7f;
        float u = t - 1f;
        return 1f + u * u * ((s + 1f) * u + s);
    }

    private void drawActive(Canvas c, long now) {
        float W = getWidth(), H = getHeight();
        fill.setShader(null);
        float tint = overtime ? 0.18f + 0.10f * (float) Math.sin(now / 120.0) : 0.10f;
        fill.setColor(alphaColor(0xFF0000, tint));
        c.drawRect(0f, 0f, W, H, fill);
        if (overtime) glitchBars(c, now, 0.7f, 0xFF2030);

        for (int i = 0; i < wins.size(); i++) {
            Win w = wins.get(i);
            long age = now - w.born;
            if (age < 0) continue;
            if (age < 40) sfxPopOnce(w, now);
            float k = easeOutBack(Math.min(1f, age / 240f));
            float ww = w.w * k, hh = w.h * k;
            float jx = 0f, jy = 0f;
            rnd.setSeed((long) w.seed + now / 110L);
            if (rnd.nextInt(14) == 0) {
                jx = (rnd.nextFloat() - 0.5f) * 8f * dp;
                jy = (rnd.nextFloat() - 0.5f) * 4f * dp;
            }
            float x = w.x + (w.w - ww) / 2f + jx;
            float y = w.y + (w.h - hh) / 2f + jy;
            drawWinBody(c, w, x, y, ww, hh, now);
        }

        drawRansomWindow(c, now);

        // монеты
        for (int i = 0; i < coins.size(); i++) {
            Coin co = coins.get(i);
            if (co.taken) continue;
            float t = now / 1000f;
            float spin = co.phase + t * 3.2f;
            float flick = (float) Math.sin(t * 2.1f + co.phase * 3f);
            float cr = 14f * dp * (0.92f + 0.08f * (float) Math.sin(t * 5f + co.phase));
            drawCoin(c, co.x, co.y + (float) Math.sin(t * 2f + co.phase) * 2f * dp, cr, spin,
                    flick > 0.93f ? 0.45f : 1f);
            // блик-искорка
            float sp = (float) Math.max(0.0, Math.sin(t * 3f + co.phase * 2f));
            if (sp > 0.75f) {
                float sl = cr * 0.9f * sp;
                line.setStrokeWidth(1.5f * dp);
                line.setColor(0xFFFFFFFF);
                c.drawLine(co.x + cr * 0.6f - sl * 0.5f, co.y - cr * 0.7f, co.x + cr * 0.6f + sl * 0.5f, co.y - cr * 0.7f, line);
                c.drawLine(co.x + cr * 0.6f, co.y - cr * 0.7f - sl * 0.5f, co.x + cr * 0.6f, co.y - cr * 0.7f + sl * 0.5f, line);
            }
        }

        // монеты, летящие в счётчик
        for (int i = 0; i < flies.size(); i++) {
            Fly f = flies.get(i);
            float k = Math.min(1f, (now - f.t0) / 380f);
            float e = k * k;
            float tx = counterRect.left + 14f * dp, ty = (counterRect.top + counterRect.bottom) / 2f;
            drawCoin(c, f.sx + (tx - f.sx) * e, f.sy + (ty - f.sy) * e, 14f * dp * (1f - 0.35f * k), now / 90f, 1f);
        }
    }

    private void sfxPopOnce(Win w, long now) {
        // звук появления окна: не чаще чем раз в 120 мс
        if (now - lastGlitchSfx > 120) {
            lastGlitchSfx = now;
            sfx.play(RansomSfx.POP);
        }
    }

    private void drawCoin(Canvas c, float cx, float cy, float r, float spin, float alpha) {
        float sx = Math.max(0.2f, Math.abs((float) Math.cos(spin)));
        c.save();
        c.translate(cx, cy);
        c.scale(sx, 1f);
        fill.setShader(null);
        fill.setColor(alphaColor(0xB8860B, alpha));
        c.drawCircle(0f, 0f, r, fill);
        fill.setColor(alphaColor(0xFFD34D, alpha));
        c.drawCircle(0f, 0f, r * 0.86f, fill);
        line.setStrokeWidth(Math.max(1f, r * 0.12f));
        line.setColor(alphaColor(0xE0A21A, alpha));
        c.drawCircle(0f, 0f, r * 0.58f, line);
        fill.setColor(alphaColor(0xFFF2A0, alpha));
        c.drawCircle(-r * 0.3f, -r * 0.3f, r * 0.16f, fill);
        c.restore();
    }

    private void drawRansomWindow(Canvas c, long now) {
        float shake = now < shakeUntil || overtime ? (rnd.nextFloat() - 0.5f) * 5f * dp : 0f;
        float x = rx + shake, y = ry;
        float th = 11f * dp;
        float B = rh - th;
        float hh = B * 0.40f, sh = B * 0.30f;
        fill.setShader(null);
        // тень
        fill.setColor(0x66000000);
        c.drawRect(x + 4f * dp, y + 4f * dp, x + rw + 4f * dp, y + rh + 4f * dp, fill);
        // заголовок окна
        fill.setColor(0xFFE6E6E6);
        c.drawRect(x, y, x + rw, y + th, fill);
        fill.setColor(0xFF9A9A9A);
        for (int i = 0; i < 3; i++) c.drawCircle(x + rw - (6f + i * 8f) * dp, y + th / 2f, 2f * dp, fill);
        // шапка
        fill.setColor(0xFFE8294C);
        c.drawRect(x, y + th, x + rw, y + th + hh, fill);
        // «череп» вымогателя
        float sr = hh * 0.36f, scx = x + hh * 0.60f, scy = y + th + hh / 2f;
        fill.setColor(0xFF121212);
        c.drawCircle(scx, scy, sr, fill);
        rnd.setSeed(now / 120L + 5L);
        fill.setColor(0xFFDDDDDD);
        for (int i = 0; i < 14; i++) {
            float a = rnd.nextFloat() * 6.28f, d = sr * (0.65f + rnd.nextFloat() * 0.4f);
            c.drawCircle(scx + (float) Math.cos(a) * d, scy + (float) Math.sin(a) * d, 1.6f * dp, fill);
        }
        fill.setColor(0xFFFF2040);
        c.drawCircle(scx - sr * 0.35f, scy - sr * 0.1f, sr * 0.14f, fill);
        c.drawCircle(scx + sr * 0.35f, scy - sr * 0.1f, sr * 0.14f, fill);
        // заголовок
        text.setTextAlign(Paint.Align.LEFT);
        text.setColor(0xFFFFFFFF);
        text.setTextSize(hh * 0.20f);
        float tx = x + hh * 1.15f;
        c.drawText("YOUR ITEMS", tx, y + th + hh * 0.34f, text);
        c.drawText("HAVE BEEN", tx, y + th + hh * 0.58f, text);
        c.drawText("ENCRYPTED", tx, y + th + hh * 0.82f, text);
        // чёрная полоса с текстом
        fill.setColor(0xFF0B0B0B);
        c.drawRect(x + 6f * dp, y + th + hh + 4f * dp, x + rw - 6f * dp, y + th + hh + sh - 2f * dp, fill);
        text.setTextSize(sh * 0.19f);
        text.setColor(0xFFFFFFFF);
        c.drawText("IF YOU DO NOT PAY THIS RANSOM BEFORE", x + 12f * dp, y + th + hh + sh * 0.40f, text);
        c.drawText("THE TIMER ENDS, YOUR ITEMS WILL BE LOST", x + 12f * dp, y + th + hh + sh * 0.72f, text);
        // нижняя часть
        fill.setColor(0xFFE8294C);
        c.drawRect(x, y + th + hh + sh - 2f * dp, x + rw, y + rh, fill);
        // счётчик монет
        float oy = 0f;
        rect2.set(counterRect.left + shake, counterRect.top, counterRect.right + shake, counterRect.bottom);
        fill.setColor(0xFF0B0B0B);
        c.drawRoundRect(rect2, 4f * dp, 4f * dp, fill);
        drawCoin(c, rect2.left + 14f * dp, (rect2.top + rect2.bottom) / 2f, 8f * dp, 0f, 1f);
        text.setTextSize(Math.min(15f * dp, rect2.bottom - rect2.top - 10f * dp));
        text.setColor(collected >= NEED ? 0xFFFFD34D : 0xFFFFFFFF);
        c.drawText(Math.min(collected, NEED) + " / " + NEED, rect2.left + 28f * dp, (rect2.top + rect2.bottom) / 2f + 5f * dp, text);
        // кнопка PAY
        rect2.set(payRect.left + shake, payRect.top, payRect.right + shake, payRect.bottom);
        boolean ok = canPay();
        float pulse = ok ? 0.5f + 0.5f * (float) Math.sin(now / 150.0) : 0f;
        fill.setColor(ok ? ((0xFF << 24) | ((int) (200 + 55 * pulse) << 16) | 0x2020) : 0xFF6A1020);
        c.drawRoundRect(rect2, 4f * dp, 4f * dp, fill);
        line.setStrokeWidth(1.4f * dp);
        line.setColor(ok ? 0xFFFFFFFF : 0x88FFFFFF);
        c.drawRoundRect(rect2, 4f * dp, 4f * dp, line);
        text.setTextAlign(Paint.Align.CENTER);
        text.setColor(ok ? 0xFFFFFFFF : 0xAAFFFFFF);
        text.setTextSize(Math.min(14f * dp, (rect2.bottom - rect2.top) * 0.42f));
        long left = Math.max(0L, TIMER_MS - (now - activeStart));
        String tm = String.format("%02d:%02d", left / 60000L, (left / 1000L) % 60L);
        String label = ok ? "PAY " + NEED + "   " + tm : "NEED " + NEED + "   " + tm;
        c.drawText(label, (rect2.left + rect2.right) / 2f, (rect2.top + rect2.bottom) / 2f + 5f * dp, text);
        text.setTextAlign(Paint.Align.LEFT);
        // рамка окна
        line.setStrokeWidth(1.2f * dp);
        line.setColor(0xFFFFFFFF);
        rect2.set(x, y, x + rw, y + rh);
        c.drawRect(rect2, line);
    }

    private void drawPaid(Canvas c, long now) {
        float W = getWidth(), H = getHeight();
        long age = now - stateStart;
        // осколки
        for (int i = shards.size() - 1; i >= 0; i--) {
            Shard s = shards.get(i);
            long a = now - s.born;
            if (a > s.life) {
                shards.remove(i);
                continue;
            }
            s.x += s.vx;
            s.y += s.vy;
            s.vy += 0.35f * dp;
            s.rot += s.vr;
            float k = 1f - (float) a / s.life;
            c.save();
            c.translate(s.x, s.y);
            c.rotate(s.rot);
            fill.setColor(alphaColor(s.color, k));
            c.drawRect(-s.w / 2f, -s.h / 2f, s.w / 2f, s.h / 2f, fill);
            c.restore();
        }
        float fade = age < 400 ? age / 400f : (age > PAID_MS - 600 ? Math.max(0f, (PAID_MS - age) / 600f) : 1f);
        fill.setShader(null);
        fill.setColor(alphaColor(0x200000, 0.35f * fade));
        c.drawRect(0f, 0f, W, H, fill);
        float bw = Math.min(W - 40f * dp, 300f * dp), bh = 70f * dp, cy = H * 0.42f;
        rect.set(W / 2f - bw / 2f, cy - bh / 2f, W / 2f + bw / 2f, cy + bh / 2f);
        fill.setColor(alphaColor(0x15161C, 0.92f * fade));
        c.drawRoundRect(rect, 16f * dp, 16f * dp, fill);
        line.setStrokeWidth(2f * dp);
        line.setColor(alphaColor(0xFFD34D, fade));
        c.drawRoundRect(rect, 16f * dp, 16f * dp, line);
        drawCoin(c, rect.left + 36f * dp, cy, 18f * dp, age / 140f, fade);
        text.setTextAlign(Paint.Align.LEFT);
        text.setColor(alphaColor(0xFFFFFF, fade));
        text.setTextSize(20f * dp);
        c.drawText("RANSOM PAID", rect.left + 66f * dp, cy - 4f * dp, text);
        text.setTextSize(12f * dp);
        text.setColor(alphaColor(0xB8BBC8, fade));
        c.drawText("Предметы расшифрованы · выкупов: " + paidTotal, rect.left + 66f * dp, cy + 18f * dp, text);
    }

    private void drawButton(Canvas c, long now) {
        if (bx < 0f) return;
        float pulse = 1f;
        if (state != IDLE && state != PAID) pulse = 1f + 0.08f * (float) Math.sin(now / 110.0);
        fill.setShader(null);
        fill.setColor(0x66000000);
        c.drawCircle(bx + 1.5f * dp, by + 2f * dp, br * 1.02f, fill);
        drawStop(c, bx, by, br * pulse);
    }

    private void safeLog(String s) {
        try {
            logger.log(s);
        } catch (Throwable ignored) {
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
