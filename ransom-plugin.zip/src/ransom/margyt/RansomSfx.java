package ransom.margyt;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

import java.util.Random;

/** Звуки события, синтезируются кодом (файлов в плагине нет). */
final class RansomSfx {

    static final int INTRO = 0, GLITCH = 1, COIN = 2, ERROR = 3, PAID = 4, POP = 5;
    private static final int RATE = 22050;

    private final AudioTrack[] tracks = new AudioTrack[6];
    private volatile boolean released;

    RansomSfx() {
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    for (int i = 0; i < tracks.length && !released; i++) {
                        AudioTrack t = build(make(i));
                        if (released) {
                            free(t);
                        } else {
                            tracks[i] = t;
                        }
                    }
                } catch (Throwable ignored) {
                }
            }
        });
        th.setDaemon(true);
        th.start();
    }

    void play(int id) {
        try {
            AudioTrack t = tracks[id];
            if (t == null) return;
            t.stop();
            t.setPlaybackHeadPosition(0);
            t.play();
        } catch (Throwable ignored) {
        }
    }

    void release() {
        released = true;
        for (int i = 0; i < tracks.length; i++) {
            free(tracks[i]);
            tracks[i] = null;
        }
    }

    private static void free(AudioTrack t) {
        try {
            if (t != null) {
                t.stop();
                t.release();
            }
        } catch (Throwable ignored) {
        }
    }

    private static AudioTrack build(short[] pcm) {
        AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC, RATE,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                pcm.length * 2, AudioTrack.MODE_STATIC);
        t.write(pcm, 0, pcm.length);
        return t;
    }

    private static short[] make(int id) {
        switch (id) {
            case INTRO:
                return intro();
            case GLITCH:
                return glitch();
            case COIN:
                return coin();
            case ERROR:
                return error();
            case PAID:
                return paid();
            default:
                return pop();
        }
    }

    private static short[] norm(float[] x, float level) {
        float peak = 0.0001f;
        for (int i = 0; i < x.length; i++) peak = Math.max(peak, Math.abs(x[i]));
        short[] o = new short[x.length];
        float k = level * 32767f / peak;
        for (int i = 0; i < x.length; i++) o[i] = (short) (x[i] * k);
        return o;
    }

    /** Низкий нарастающий гул со шумом и «статическим» треском. */
    private static short[] intro() {
        int n = (int) (RATE * 1.4f);
        float[] x = new float[n];
        Random r = new Random(5);
        double ph = 0;
        for (int i = 0; i < n; i++) {
            float t = i / (float) RATE;
            float u = t / 1.4f;
            float f = 60f + 220f * u * u;
            ph += 2.0 * Math.PI * f / RATE;
            float env = (float) Math.min(1.0, u * 4.0) * (1f - u * 0.5f);
            float saw = (float) (((ph / (2 * Math.PI)) % 1.0) * 2.0 - 1.0);
            float crackle = r.nextFloat() < 0.04f + 0.1f * u ? (r.nextFloat() * 2f - 1f) : 0f;
            x[i] = (saw * 0.6f + (float) Math.sin(ph) * 0.4f + crackle * 0.9f) * env;
        }
        return norm(x, 0.7f);
    }

    /** Короткий цифровой сбой. */
    private static short[] glitch() {
        int n = (int) (RATE * 0.35f);
        float[] x = new float[n];
        Random r = new Random(9);
        float hold = 0f;
        int len = 1;
        for (int i = 0; i < n; i++) {
            if (i % len == 0) {
                hold = r.nextFloat() * 2f - 1f;
                len = 4 + r.nextInt(40);
            }
            float env = 1f - i / (float) n;
            x[i] = hold * env * ((i / 900) % 2 == 0 ? 1f : 0.3f);
        }
        return norm(x, 0.45f);
    }

    /** Звонкая монета. */
    private static short[] coin() {
        int n = (int) (RATE * 0.5f);
        float[] x = new float[n];
        for (int i = 0; i < n; i++) {
            float t = i / (float) RATE;
            float f = t < 0.07f ? 1318f : 1760f;
            float env = (float) Math.exp(-t * 7.0);
            x[i] = ((float) Math.sin(2 * Math.PI * f * t) + 0.35f * (float) Math.sin(2 * Math.PI * f * 2.01 * t)) * env;
        }
        return norm(x, 0.6f);
    }

    /** Отказ: два низких зуммера. */
    private static short[] error() {
        int n = (int) (RATE * 0.4f);
        float[] x = new float[n];
        for (int i = 0; i < n; i++) {
            float t = i / (float) RATE;
            float gate = (t % 0.2f) < 0.14f ? 1f : 0f;
            float sq = Math.sin(2 * Math.PI * 140 * t) > 0 ? 1f : -1f;
            x[i] = sq * gate * 0.6f;
        }
        return norm(x, 0.5f);
    }

    /** Оплата: монеты и восходящий аккорд. */
    private static short[] paid() {
        int n = (int) (RATE * 1.1f);
        float[] x = new float[n];
        float[] notes = {784f, 988f, 1175f, 1568f};
        for (int k = 0; k < notes.length; k++) {
            int start = (int) (RATE * 0.09f * k);
            for (int i = start; i < n; i++) {
                float t = (i - start) / (float) RATE;
                float env = (float) Math.exp(-t * 4.5);
                x[i] += (float) Math.sin(2 * Math.PI * notes[k] * t) * env * 0.5f;
            }
        }
        return norm(x, 0.65f);
    }

    /** Появление окна. */
    private static short[] pop() {
        int n = (int) (RATE * 0.12f);
        float[] x = new float[n];
        Random r = new Random(3);
        for (int i = 0; i < n; i++) {
            float t = i / (float) RATE;
            float env = 1f - i / (float) n;
            x[i] = ((float) Math.sin(2 * Math.PI * (500f + 900f * t) * t) * 0.7f + (r.nextFloat() - 0.5f) * 0.3f) * env;
        }
        return norm(x, 0.35f);
    }
}
